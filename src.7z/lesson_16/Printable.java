package lesson_16;

public interface Printable {
    void Print();
}
