package lesson_16;

public interface Reportable {

    String getReport();

}
