package lesson_16;

public class Printer {
    public static void print(Printable p) {
        p.Print();
    }
}
