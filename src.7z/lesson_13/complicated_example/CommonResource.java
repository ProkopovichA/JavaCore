package lesson_13.complicated_example;

public class CommonResource {
    int x = 0;
}
