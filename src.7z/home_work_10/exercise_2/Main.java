package home_work_10.exercise_2;

public class Main {
    public static void main(String[] args) {
        UtilClass.ioWrite("test1.txt");
        UtilClass.ioRead("test1.txt");
    }
}
