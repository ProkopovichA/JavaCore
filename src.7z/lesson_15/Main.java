package lesson_15;

public class Main {
    public static void main(String[] args) {

        new CallableHomeWork();
    }
}
