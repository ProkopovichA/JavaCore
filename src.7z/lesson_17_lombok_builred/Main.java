package lesson_17_lombok_builred;

public class Main {
    public static void main(String[] args) {
        //System.out.println(Car.builder().name("Lamba").seats(5).build());

//        Car car = new Car();
//        car.setSeats(5);
//        car.setName("Lamba");
//        System.out.println(car);

    }
}
