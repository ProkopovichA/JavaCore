package lesson_11;

public class SillyChoseException extends Exception{
    public SillyChoseException(String message) {
        super(message);
    }
}
