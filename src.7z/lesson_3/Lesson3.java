package lesson_3;

public class Lesson3 {
    public static void main(String[] args) {

    }
}
