package lesson_9;

public interface Accountable <T>{

    T getId();
    int getSum();
    void setSum(int sum);

}
