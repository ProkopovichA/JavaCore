package home_work_7.exercise_6;

public class Tulips extends Flowers{
    public Tulips(String name, int dayOfLife, String color, int cost) {
        super(name, dayOfLife, color, cost);
    }
}
