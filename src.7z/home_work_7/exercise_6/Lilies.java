package home_work_7.exercise_6;

public class Lilies extends Flowers{
    public Lilies(String name, int dayOfLife, String color, int cost) {
        super(name, dayOfLife, color, cost);
    }
}
