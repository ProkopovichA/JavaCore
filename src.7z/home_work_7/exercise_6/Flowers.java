package home_work_7.exercise_6;

public class Flowers {
    public String name;
    public int dayOfLife;
    public String color;
    public int cost;

    public Flowers(String name, int dayOfLife, String color, int cost) {
        this.name = name;
        this.dayOfLife = dayOfLife;
        this.color = color;
        this.cost = cost;
    }
}
