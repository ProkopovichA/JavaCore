package home_work_7.exercise_2;

public class Cube {
    public int sideA;

    public Cube() {
    }

    public Cube(int sideA) {
        this.sideA = sideA;
    }

    public int getSideA() {
        return sideA;
    }

    public void setSideA(int sideA) {
        this.sideA = sideA;
    }
}
