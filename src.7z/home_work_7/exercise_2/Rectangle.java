package home_work_7.exercise_2;

public class Rectangle extends RectangularParallelepiped {
    public int sideC;

    public Rectangle(int sideA, int sideB, int sideC) {
        super(sideA, sideB);
        this.sideC = sideC;
    }
}
