package home_work_7.exercise_2;

public class Main {
    public static void main(String[] args) {

    }
}
