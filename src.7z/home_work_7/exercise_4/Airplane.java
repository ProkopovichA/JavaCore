package home_work_7.exercise_4;

public class Airplane extends FlyingMachines {

    public Airplane(String name, int spaciousness, int loadCapacity, int rangeOfFlight) {
        super(name, spaciousness, loadCapacity, rangeOfFlight);
    }
}
