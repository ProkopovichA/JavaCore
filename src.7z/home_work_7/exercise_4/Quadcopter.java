package home_work_7.exercise_4;

public class Quadcopter extends Helicopter {

    public Quadcopter(String name, int spaciousness, int loadCapacity, int rangeOfFlight) {
        super(name, spaciousness, loadCapacity, rangeOfFlight);
    }
}
