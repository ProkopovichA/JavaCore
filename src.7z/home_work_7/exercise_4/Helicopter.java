package home_work_7.exercise_4;

public class Helicopter extends FlyingMachines {

    public Helicopter(String name, int spaciousness, int loadCapacity, int rangeOfFlight) {
        super(name, spaciousness, loadCapacity, rangeOfFlight);
    }
}
