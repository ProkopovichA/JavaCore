package home_work_7.exercise_4;

public class FlyingMachines {
    public String name;
    public int spaciousness;
    public int loadCapacity;
    public int rangeOfFlight;

    public FlyingMachines(String name, int spaciousness, int loadCapacity, int rangeOfFlight) {
        this.name = name;
        this.spaciousness = spaciousness;
        this.loadCapacity = loadCapacity;
        this.rangeOfFlight = rangeOfFlight;
    }


}
