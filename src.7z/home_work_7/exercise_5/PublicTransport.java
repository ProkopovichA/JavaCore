package home_work_7.exercise_5;

public class PublicTransport {
    public String name;
    public int cost;
    public int fuelConsumption;

    public PublicTransport(String name, int cost, int fuelConsumption) {
        this.name = name;
        this.cost = cost;
        this.fuelConsumption = fuelConsumption;
    }
}
