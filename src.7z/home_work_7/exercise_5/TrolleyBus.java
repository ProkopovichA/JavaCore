package home_work_7.exercise_5;

public class TrolleyBus extends PublicTransport {
    public TrolleyBus(String name, int cost, int fuelConsumption) {
        super(name, cost, fuelConsumption);
    }
}
