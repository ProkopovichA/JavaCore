package home_work_7.exercise_5;

public class Tram extends PublicTransport{
    public Tram(String name, int cost, int fuelConsumption) {
        super(name, cost, fuelConsumption);
    }
}
