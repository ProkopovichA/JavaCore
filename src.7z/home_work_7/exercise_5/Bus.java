package home_work_7.exercise_5;

public class Bus extends PublicTransport {

    public Bus(String name, int cost, int fuelConsumption) {
        super(name, cost, fuelConsumption);
    }
}
