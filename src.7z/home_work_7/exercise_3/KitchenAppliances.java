package home_work_7.exercise_3;

public class KitchenAppliances extends Technique {

    public KitchenAppliances(String deviceName, int power) {
        super(deviceName, power);
    }
}
