package home_work_7.exercise_3;

public class OtherAppliances extends Technique {

    public OtherAppliances(String deviceName, int power) {
        super(deviceName, power);
    }
}